---
layout: default
title: Custom page by teo
nav_order: 6
---

# Customization
{: .no_toc }

## Table of contents
{: .no_toc .text-delta }

1. TOC
{:toc}

### MY TIELS

## Color schemes
{: .d-inline-block }

New
{: .label .label-green }

